
import './App.css';
import React from "react";
import SidebarMenu from "./SidebarMenu";

function App() {
  const [message,setMessage]=React.useState("");
  const [predicthumidity,setHumidity]=React.useState(null);
  const [predicttemp,setTemperature]=React.useState(null);
  const [predictpressure,setPressure]=React.useState(null);
  const [predicthumidity1,setHumidity1]=React.useState(null);
  const [predicttemp1,setTemperature1]=React.useState(null);
  const [predictpressure1,setPressure1]=React.useState(null);
  const [predicthumidity2,setHumidity2]=React.useState(null);
  const [predicttemp2,setTemperature2]=React.useState(null);
  const [predictpressure2,setPressure2]=React.useState(null);

  function Weatherinfo(event){
    setMessage(event.target.value);

    console.log('value is:', event.target.value);
  };
  function Fetchfunc(){
      fetch(`https://api.openweathermap.org/data/2.5/forecast?q=${message}&APPID=6557810176c36fac5f0db536711a6c52`)
      .then((res)=>res.json())
      .then((data)=>{
             setHumidity(data.list[0].main.humidity);
             setTemperature(data.list[0].main.temp_kf);
             setPressure(data.list[0].main.pressure);
             setHumidity1(data.list[7].main.humidity);
             setTemperature1(data.list[7].main.temp_kf);
             setPressure1(data.list[7].main.pressure);
             setHumidity2(data.list[15].main.humidity);
             setTemperature2(data.list[15].main.temp_kf);
             setPressure2(data.list[15].main.pressure);
             console.log(data);
  });
}
  return (
    <div className="App">
        <header  className="App-header">
        <SidebarMenu />
        <box border="1" id="table">
        <h1 className="header1" align="center">Weather Forecast</h1>
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css"></link>
        <div align="center">
        <form className="example" action="/action_page.php">
        <input type="text" placeholder="Search.." name="search2" value={message} onChange={Weatherinfo}></input>
        <button type="submit" onClick={Fetchfunc}><i className="fa fa-search"></i></button>
        </form>
        </div>
        </box>
        <br />
        <div className="container0">
        
        <div className="container1">
        <h3 align="center">Day 1</h3>
        {predicthumidity && <h6 align="center"><img src="humidityimg.png" alt="humiditygif" id="humiditygif" />Humidity:{predicthumidity} g.m-3</h6>}
        {predicttemp &&  <h6 align="center"><img src="temperatureimg.png" alt="temperaturegif" id="humiditygif" />Temperature:{predicttemp} C</h6> }
        {predictpressure &&  <h6 align="center"><img src="pressureimg.png" alt="pressuregif" id="humiditygif" />Pressure:{predictpressure} pa</h6> }
        </div>
        
        <div className="container1">
        <h3 align="center">Day 2</h3>
        {predicthumidity && <h6 align="center"><img src="humidityimg.png" alt="humiditygif" id="humiditygif" />Humidity:{predicthumidity1} g.m-3</h6>}
        {predicttemp &&  <h6 align="center"><img src="temperatureimg.png" alt="temperaturegif" id="humiditygif" />Temperature:{predicttemp1} C</h6> }
        {predictpressure &&  <h6 align="center"><img src="pressureimg.png" alt="pressuregif" id="humiditygif" />Pressure:{predictpressure1} Pa</h6> }
        </div>
       
        <div className="container1">
        <h3 align="center">Day 3</h3>
        {predicthumidity && <h6 align="center"><img src="humidityimg.png" alt="humiditygif" id="humiditygif" />Humidity:{predicthumidity2} g.m-3</h6>}
        {predicttemp &&  <h6 align="center"><img src="temperatureimg.png" alt="temperaturegif" id="humiditygif" />Temperature:{predicttemp2} C</h6> }
        {predictpressure &&  <h6 align="center"><img src="pressureimg.png" alt="pressuregif" id="humiditygif" />Pressure:{predictpressure2} Pa</h6> }
        </div>
        </div>
        </header>   
    </div>   
);
}
export default App;

