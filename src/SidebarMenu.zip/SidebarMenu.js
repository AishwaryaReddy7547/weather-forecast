import React from "react";
import './SidebarMenu.css';
import App from "./App.js";
import Day1 from "./Day1.js";
import Day2 from "./Day2.js";
import Day3 from "./Day3.js";
function SidebarMenu(props){
    return(
       <div class="sidebar">
       <a href="#home" onClick={App}><i class="fa fa-home"></i> Home</a>
       <br />
       <a href="#services" onClick={Day1}><i class="fa fa-calendar"></i> 1 day</a>
       <br />
       <a href="#clients" onClick={Day2}><i class="fa fa-calendar"></i> 2 days</a>
       <br />
       <a href="#contact" onClick={Day3}><i class="fa fa-calendar"></i> 3 days</a>
       </div>
    );
}
export default SidebarMenu;